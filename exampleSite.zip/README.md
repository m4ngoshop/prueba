# Hugo example site for [Pico](https://github.com/negrel/hugo-theme-pico/) theme

See [instructions](https://github.com/negrel/hugo-theme-pico/)