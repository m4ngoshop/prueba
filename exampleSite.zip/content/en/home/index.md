+++
# Homepage
headless = true  # Homepage is headless, other widget pages are not.
+++
