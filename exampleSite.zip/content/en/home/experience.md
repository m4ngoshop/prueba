+++
widget = "timeline"
weight = 30  # Order that this section will appear.

# Uncomment the following line and widget will NOT be displayed
# hidden = true

# Widget title
title = "Experience"
# Widget subtitle
subtitle = "What lead me to acquire experience."

date_format = "Jan 2006" # Date format https://gohugo.io/functions/dateformat/#readout

[[period]]
  title = "Chief cook"
  subtitle = "Krusty krab"
  location = "Bikini Bottom"
  date_start = "2017-01-01"
  date_end = ""
  description = "Chief cook of the biggest restaurant of Bikini Bottom."

[[period]]
  title = "Trainee cook"
  subtitle = "Krusty krab"
  location = "California"
  date_start = "2016-01-01"
  date_end = "2016-12-31"
  description = "I learned the basics of cooking, the passion and the secrets of a good burger."
+++