+++
# A Recent Blog Posts section created with the Pages widget.
# This section displays recent blog posts from `content/post/`.

# Uncomment the following line and widget will NOT be displayed
# hidden = true

widget = "pages"  # See https://sourcethemes.com/academic/docs/page-builder/
weight = 50  # Order that this section will appear.

title = "Recent Posts"
subtitle = "Read about my latest projects"

[content]
	# Page type to display. E.g. post, talk, or publication.
	page_type = "blog"

	# Choose how much pages you would like to display
	count = 5

	[content.filters]
		tag = "recipe"
		category = ""
		publication_type = ""
		exclude_featured = false
+++

:disappointed: There are no posts at the moment. :disappointed: