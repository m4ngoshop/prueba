+++
title = "About me"

type = "blog"
+++

I'm a **sea sponge** who works as a fry cook at the **Krusty Krab**:
![](/img/krusty_krab.webp)

The Krusty Krabe is a fast food restaurant known for it's signature burger:

![*The Krabby Patty*](/img/krabby_patty.webp)

Try to make one yourself and you will be as happy as I am.
![My first Krabby Patty](/img/spongebob-krusty-cook.webp)

You can take a look at the recipe [here](/blog/krabby_patty/).