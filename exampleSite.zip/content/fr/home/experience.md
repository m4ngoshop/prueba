+++
widget = "timeline"
weight = 30  # Order that this section will appear.

# Uncomment the following line and widget will NOT be displayed
# hidden = true

# Widget title
title = "Expérience"
# Widget subtitle
subtitle = "Ce qui m'a mené à acquérir de l'expérience"

date_format = "02.01.2006" # Date format https://gohugo.io/functions/dateformat/#readout

[[period]]
  title = "Cuisinier en chef"
  subtitle = "Krusty Krab"
  location = "Bikini Bottom"
  date_start = "2017-01-01"
  date_end = ""
  description = "Cuisinier en chef du plus grand restaurant de Bikini Bottom."

[[period]]
  title = "Stagiaire cuisinier"
  subtitle = "Krusty Krab"
  location = "France"
  date_start = "2016-01-01"
  date_end = "2016-12-31"
  description = "J'ai appris les bases de la cuisine, la passion et les secrets d'un bon burger"
  
+++