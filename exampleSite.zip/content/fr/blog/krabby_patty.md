+++
title = "Recette du Krabby Patty"
subtitle = "Comment le meilleur burger de tout les temps est fait."
tags = ['recipe']
date = 2020-06-25

# For description meta tag
description = "Recette du légendaire Krabby Patty."

# Comment next line and the default banner wil be used.
banner = 'img/krabby_patty.webp'

+++

## Ingrédients :

Pour 4 personnes :
- Beaucoup d'amour
- 2 boîtes de chair de crabe
- 1 œuf légèrement battu
- Jus de 1/2 citron
- Chapelure
- 1 tomate
- Pain à hamburger
- Cornichons
- 1 Oignon
- 4 feuilles de salade
- Huile de friture
- Sel & poivre

Pour la sauce :
- Sauce Worcestershire
- Ketchup
- Moutarde

## Les étapes :

- Dans un saladier, battre 1 œuf puis ajouter la chair de crabe, la chapelure, le jus de citron, le sel et le poivre. Mélanger jusqu’à obtenir une consistance homogène.

- Former ensuite des steaks de pâté de crabe puis les faire dorer dans une poêle avec un filet d’huile de friture pendant 4 à 5 minutes sur chaque face.

- Entre-temps, réaliser la sauce. Mélanger la sauce Worcestershire avec la moutarde et le ketchup. Goûter puis modifier l’assaisonnement si besoin.

- Réserver les steaks de pâté de crabe sur un papier absorbant puis faire colorer quelques minutes les pains à burger.

- Détailler la tomate en rondelles, émincer l’oignon et couper les cornichons en morceaux.

- Dresser les steaks de pâté de crabe sur chaque pain à burger puis ajouter une feuille de salade, quelques rondelles de tomate, des oignons et des cornichons.

- Agrémenter le tout de sauce et recouvrir de pain à burger avant de déguster ces délicieux krabby Krab !

