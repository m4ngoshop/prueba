+++
title = "À propos"

type = "blog"
+++

Je suis une **éponge de mer** qui travaille comme cuisinier au ** Krusty Krab **:
![](/img/krusty_krab.webp)

Le Krusty Krabe est un restaurant de restauration rapide connu pour son burger signature:
![*Le Krabby Patty*](/img/krabby_patty.webp)

Essayez d'en faire un vous-même et vous serez aussi heureux que moi.
![Ma première Krabby Patty](/img/spongebob-krusty-cook.webp)

Vous pouvez jeter un œil à la recette [ici](/blog/krabby_patty/).